﻿# Playwright Browser Skill for OpenClaw - Windows 版本
版本: 2.1.0

## 快速安装

### 方法一：双击运行（最简单，推荐）

1. 解压此文件到任意目录
2. 双击运行 `auto-deploy.cmd`（中文版）
3. 或双击运行 `auto-deploy-en.cmd`（英文版）
4. 重启 OpenClaw

**推荐使用此方法**，因为大部分 Windows 电脑默认禁止运行 PowerShell 脚本。

### 方法二：命令提示符

1. 解压此文件到任意目录
2. 在此目录打开命令提示符
3. 运行部署脚本：

```cmd
auto-deploy.cmd
```

或使用英文版本：

```cmd
auto-deploy-en.cmd
```

### 方法三：PowerShell（需要执行策略权限）

1. 解压此文件到任意目录
2. 在此目录打开 PowerShell
3. 如果提示执行策略错误，先运行：

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```

4. 然后运行部署脚本：

```powershell
.\auto-deploy.ps1
```

或使用英文版本：

```powershell
.\auto-deploy-en.ps1
```

### 方法四：手动部署

1. 复制整个文件夹到：
   ```
   C:\Users\你的用户名\.openclaw\skills\playwright-browser\
   ```

2. 编辑配置文件：
   ```
   C:\Users\你的用户名\.openclaw\settings\mcp.json
   ```

3. 添加以下配置：
   ```json
   {
     "mcpServers": {
       "playwright-browser": {
         "command": "node",
         "args": ["C:\\Users\\你的用户名\\.openclaw\\skills\\playwright-browser\\dist\\mcp-server.js"],
         "disabled": false
       }
     }
   }
   ```

4. 重启 OpenClaw

## 使用说明

部署完成后，在 OpenClaw 对话中输入：

```
请使用 Playwright Browser Skill 技能来访问互联网和控制浏览器
```

然后就可以使用浏览器相关功能了！

## 包含内容

- ✅ 编译后的代码 (dist/)
- ✅ 完整依赖包 (node_modules/)
- ✅ 技能文档 (skill-package/)
- ✅ 自动部署脚本（.cmd 和 .ps1）
- ✅ 完整文档

## 系统要求

- Windows 10/11
- Node.js 18 或更高版本

## 支持

- 📧 Email: 91fapiao@gmail.com
- 🐛 Issues: https://github.com/91fapiao-cn/playwright-browser-skill/issues
- 📚 文档: 查看 README.md

---
**Made with ❤️ for OpenClaw Community**
